import React from 'react';
import { HERO_TITLE, HERO_SUBTITLE, AUTHOR_NAME } from '../constants';

const Hero: React.FC = () => {
  return (
    <section id="home" className="relative h-screen w-full overflow-hidden bg-black flex items-center justify-center">
      {/* Background Image with Overlay */}
      <div 
        className="absolute inset-0 bg-cover bg-center opacity-60 scale-105 animate-[pulse_10s_ease-in-out_infinite]"
        style={{ backgroundImage: `url('https://picsum.photos/1920/1080?grayscale&blur=2')` }}
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent" />
      <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/stardust.png')] opacity-20"></div>

      {/* Content */}
      <div className="relative z-10 text-center px-6 max-w-5xl mx-auto">
        <p className="text-brand-red font-header font-bold tracking-[0.5em] mb-6 text-sm md:text-base animate-[fadeIn_1s_ease-out]">
          {AUTHOR_NAME} PRESENTS
        </p>
        
        <h1 className="text-5xl md:text-8xl lg:text-9xl font-header font-bold text-white tracking-tighter mb-4 leading-none uppercase mix-blend-overlay opacity-90">
          {HERO_TITLE}
        </h1>
        
        <div className="h-1 w-24 bg-brand-red mx-auto my-8"></div>

        <p className="text-gray-300 font-sans text-lg md:text-xl tracking-widest uppercase max-w-2xl mx-auto mb-12">
          {HERO_SUBTITLE}
        </p>

        <button className="group relative px-8 py-4 bg-transparent border border-white/30 overflow-hidden transition-all hover:border-brand-red">
          <div className="absolute inset-0 w-0 bg-brand-red transition-all duration-[250ms] ease-out group-hover:w-full opacity-10"></div>
          <span className="relative font-header font-bold tracking-widest text-white group-hover:text-brand-red transition-colors">
            ENTER THE WORLD
          </span>
        </button>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 opacity-50 animate-bounce">
        <span className="text-[10px] tracking-widest font-header text-gray-400">SCROLL</span>
        <div className="w-[1px] h-12 bg-gradient-to-b from-brand-red to-transparent"></div>
      </div>
    </section>
  );
};

export default Hero;