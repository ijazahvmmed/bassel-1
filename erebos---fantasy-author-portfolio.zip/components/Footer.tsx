import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-black border-t border-white/10 py-20 relative">
      <div className="container mx-auto px-6 md:px-12 md:pl-32">
        <div className="flex flex-col md:flex-row justify-between gap-12">
          
          <div className="w-full md:w-1/2">
            <h2 className="text-3xl font-header font-bold text-white uppercase mb-6">
              Join the <span className="text-brand-red">Vanguard</span>
            </h2>
            <p className="text-gray-400 font-sans mb-8 max-w-md">
              Subscribe to the newsletter for exclusive short stories, release updates, and behind-the-scenes content from the Aether Cycle.
            </p>
            <div className="flex w-full max-w-md border-b border-white/30 focus-within:border-brand-red transition-colors">
              <input 
                type="email" 
                placeholder="YOUR EMAIL ADDRESS" 
                className="bg-transparent w-full py-4 text-white font-header tracking-widest placeholder-gray-600 focus:outline-none uppercase"
              />
              <button className="text-white hover:text-brand-red transition-colors font-bold uppercase tracking-widest text-sm px-4">
                Sign Up
              </button>
            </div>
          </div>

          <div className="w-full md:w-1/3 flex flex-col gap-4 md:items-end justify-end">
            <h3 className="font-header font-bold text-white tracking-widest text-xl">EREBOS</h3>
            <div className="flex gap-6">
              {['Twitter', 'Instagram', 'Discord', 'Patreon'].map((social) => (
                <a key={social} href="#" className="text-gray-500 hover:text-brand-red transition-colors font-sans text-sm uppercase tracking-wider">
                  {social}
                </a>
              ))}
            </div>
            <p className="text-gray-700 text-xs font-sans mt-8">
              © {new Date().getFullYear()} Erebos Publishing. All rights reserved.
            </p>
          </div>

        </div>
      </div>
    </footer>
  );
};

export default Footer;