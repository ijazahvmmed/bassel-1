import React, { useState, useEffect } from 'react';
import { NAV_LINKS } from '../constants';

const Navigation: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);

  // Lock body scroll when menu is open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => { document.body.style.overflow = 'unset'; };
  }, [isOpen]);

  return (
    <>
      {/* --- Desktop Sidebar (Always Visible) --- */}
      <div className="hidden md:flex fixed left-0 top-0 h-full w-24 bg-brand-dark border-r border-white/10 z-50 flex-col items-center justify-between py-8">
        {/* Toggle Button */}
        <button 
          onClick={() => setIsOpen(!isOpen)}
          className="w-12 h-12 flex items-center justify-center text-white hover:text-brand-red transition-colors relative z-50 group focus:outline-none"
        >
          {isOpen ? (
             <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
               <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M6 18L18 6M6 6l12 12" />
             </svg>
          ) : (
            <div className="flex flex-col gap-1.5 items-center">
              <span className="w-8 h-[2px] bg-white group-hover:bg-brand-red transition-colors duration-300"></span>
              <span className="w-8 h-[2px] bg-white group-hover:bg-brand-red transition-colors duration-300"></span>
              <span className="w-8 h-[2px] bg-white group-hover:bg-brand-red transition-colors duration-300"></span>
            </div>
          )}
        </button>

        {/* Logo/Brand Vertical */}
        <div className="flex-1 flex items-center justify-center">
             <div className="writing-vertical-lr rotate-180 font-header font-bold text-2xl tracking-[0.5em] text-white opacity-80 select-none">
                EREBOS
             </div>
        </div>

        {/* Bottom Actions */}
        <div className="flex flex-col gap-8 items-center mb-4">
           <div className="writing-vertical-lr rotate-180 font-sans text-[10px] tracking-[0.2em] text-gray-500 hover:text-brand-red cursor-pointer transition-colors">
              LOGIN
           </div>
           <div className="w-[1px] h-8 bg-gray-800"></div>
           <div className="writing-vertical-lr rotate-180 font-sans font-bold text-[10px] tracking-[0.2em] text-brand-red cursor-pointer hover:text-white transition-colors">
              READ NOW
           </div>
        </div>
      </div>

      {/* --- Mobile Top Bar --- */}
      <div className="fixed top-0 left-0 w-full h-16 bg-black/90 backdrop-blur-md z-50 flex items-center justify-between px-6 md:hidden border-b border-white/10">
        <span className="font-header font-bold text-xl tracking-widest text-white">EREBOS</span>
        <button onClick={() => setIsOpen(!isOpen)} className="text-white focus:outline-none">
          {isOpen ? (
            <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
          ) : (
            <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" /></svg>
          )}
        </button>
      </div>

      {/* --- Full Screen Menu Overlay --- */}
      <div 
        className={`fixed inset-0 z-40 bg-brand-red transition-transform duration-500 ease-[cubic-bezier(0.76,0,0.24,1)] ${isOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-[-100%]'}`}
      >
        <div className="flex h-full w-full">
          {/* Spacer for Sidebar on Desktop */}
          <div className="hidden md:block w-24 flex-shrink-0 bg-brand-dark border-r border-white/10 h-full"></div>
          
          {/* Main Menu Content */}
          <div className="flex-1 flex flex-col h-full overflow-y-auto">
            
            {/* Top Search Bar */}
            <div className="h-24 min-h-[6rem] border-b border-white/20 flex items-center px-8 md:px-16">
              <input 
                type="text" 
                placeholder="Search" 
                className="w-full bg-transparent text-white placeholder-white/50 text-2xl md:text-3xl font-serif focus:outline-none"
              />
              <button className="text-white hover:opacity-70 transition-opacity">
                <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M17 8l4 4m0 0l-4 4m4-4H3" /></svg>
              </button>
            </div>

            {/* Menu Grid */}
            <div className="flex-1 p-8 md:p-16 grid grid-cols-1 md:grid-cols-12 gap-12 text-white content-start md:content-center">
              
              {/* Column 1: General Links */}
              <div className="md:col-span-3 flex flex-col gap-6 pt-4">
                <span className="font-sans text-xs font-bold tracking-[0.2em] uppercase opacity-70 mb-2">Navigation</span>
                {NAV_LINKS.map(link => (
                  <a 
                    key={link.label} 
                    href={link.href}
                    onClick={() => setIsOpen(false)}
                    className="font-sans text-sm font-bold tracking-[0.15em] hover:opacity-70 transition-opacity uppercase"
                  >
                    {link.label}
                  </a>
                ))}
                <a href="#" className="font-sans text-sm font-bold tracking-[0.15em] hover:opacity-70 transition-opacity uppercase">Newsletter</a>
                <a href="#" className="font-sans text-sm font-bold tracking-[0.15em] hover:opacity-70 transition-opacity uppercase">Community</a>
                <a href="#" className="font-sans text-sm font-bold tracking-[0.15em] hover:opacity-70 transition-opacity uppercase">Support</a>
              </div>

              {/* Column 2: World (Big Serif) */}
              <div className="md:col-span-5 flex flex-col gap-2">
                 <span className="font-sans text-xs font-bold tracking-[0.2em] uppercase opacity-70 mb-6">The World</span>
                 {['Universe', 'Cultures', 'Bestiary', 'Timeline', 'Map', 'Artifacts'].map(item => (
                   <a key={item} href="#world" onClick={() => setIsOpen(false)} className="font-serif text-4xl md:text-5xl lg:text-6xl hover:italic hover:translate-x-4 transition-all duration-300 cursor-pointer leading-tight">
                     {item}
                   </a>
                 ))}
              </div>

              {/* Column 3: Downloads/Books (Big Serif) */}
              <div className="md:col-span-4 flex flex-col gap-2">
                 <span className="font-sans text-xs font-bold tracking-[0.2em] uppercase opacity-70 mb-6">Library</span>
                 {['Books', 'Short Stories', 'Audio Logs', 'Wallpapers', 'Concept Art'].map(item => (
                   <a key={item} href="#books" onClick={() => setIsOpen(false)} className="font-serif text-4xl md:text-5xl lg:text-6xl hover:italic hover:translate-x-4 transition-all duration-300 cursor-pointer leading-tight">
                     {item}
                   </a>
                 ))}
              </div>

            </div>

            {/* Bottom Footer Area */}
            <div className="border-t border-white/20 p-8 md:px-16 md:py-8 flex flex-col md:flex-row justify-between items-center text-white/60 text-xs font-sans tracking-widest uppercase gap-4">
               <div className="flex gap-8">
                  <a href="#" className="hover:text-white cursor-pointer transition-colors">Instagram</a>
                  <a href="#" className="hover:text-white cursor-pointer transition-colors">Twitter</a>
                  <a href="#" className="hover:text-white cursor-pointer transition-colors">Patreon</a>
               </div>
               <div className="flex gap-6">
                  <span>© {new Date().getFullYear()} Erebos</span>
                  <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
               </div>
            </div>

          </div>
        </div>
      </div>
      
      <style>{`
        .writing-vertical-lr {
          writing-mode: vertical-lr;
        }
      `}</style>
    </>
  );
};

export default Navigation;