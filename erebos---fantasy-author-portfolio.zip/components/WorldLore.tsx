import React from 'react';
import { LORE_ITEMS } from '../constants';

const WorldLore: React.FC = () => {
  return (
    <section id="world" className="py-24 bg-brand-gray relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5" style={{backgroundImage: 'radial-gradient(#fff 1px, transparent 1px)', backgroundSize: '30px 30px'}}></div>

      <div className="container mx-auto px-6 md:px-12 md:pl-32 relative z-10">
        <div className="flex flex-col md:flex-row justify-between items-end mb-16 border-b border-white/10 pb-8">
          <div>
            <h3 className="text-brand-red font-header font-bold tracking-[0.3em] text-sm mb-2">EXPLORE THE UNIVERSE</h3>
            <h2 className="text-4xl md:text-5xl font-header font-bold text-white uppercase">LORE & ARTIFACTS</h2>
          </div>
          <p className="text-gray-400 max-w-sm text-sm mt-6 md:mt-0 font-sans text-right">
            Dive deep into the cultures, locations, and forbidden technology of the Aether Cycle.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {LORE_ITEMS.map((item) => (
            <div key={item.id} className="group relative h-[500px] bg-black border border-white/5 overflow-hidden">
              {/* Background Image */}
              <div className="absolute inset-0">
                <img 
                  src={item.image} 
                  alt={item.title} 
                  className="w-full h-full object-cover opacity-60 group-hover:opacity-40 group-hover:scale-110 transition-all duration-700" 
                />
                <div className="absolute inset-0 bg-gradient-to-b from-transparent via-black/20 to-black"></div>
              </div>

              {/* Content Overlay */}
              <div className="absolute inset-0 p-8 flex flex-col justify-end transform transition-transform duration-500">
                <div className="transform translate-y-4 group-hover:translate-y-0 transition-transform duration-500">
                  <span className="text-brand-red text-xs font-bold tracking-widest uppercase mb-2 block opacity-0 group-hover:opacity-100 transition-opacity duration-500 delay-100">
                    {item.category}
                  </span>
                  <h3 className="text-2xl font-header font-bold text-white mb-4 uppercase tracking-wider group-hover:text-brand-red transition-colors">
                    {item.title}
                  </h3>
                  <div className="h-[1px] w-full bg-white/20 mb-4 scale-x-0 group-hover:scale-x-100 transition-transform duration-500 origin-left"></div>
                  <p className="text-gray-300 font-sans text-sm leading-relaxed opacity-0 group-hover:opacity-100 transition-opacity duration-500 delay-200">
                    {item.excerpt}
                  </p>
                </div>
              </div>

              {/* Border Hover Effect */}
              <div className="absolute inset-0 border border-brand-red/0 group-hover:border-brand-red/50 transition-colors duration-500 pointer-events-none"></div>
            </div>
          ))}
        </div>
        
        <div className="mt-16 flex justify-center">
            <button className="bg-white text-black font-header font-bold py-4 px-12 tracking-widest hover:bg-brand-red hover:text-white transition-colors duration-300">
                VIEW FULL ATLAS
            </button>
        </div>
      </div>
    </section>
  );
};

export default WorldLore;