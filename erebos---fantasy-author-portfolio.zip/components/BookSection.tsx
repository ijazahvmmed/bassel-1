import React from 'react';
import { BOOKS } from '../constants';

const BookSection: React.FC = () => {
  return (
    <section id="books" className="py-24 bg-black relative">
      <div className="container mx-auto px-6 md:px-12 md:pl-32"> {/* Added padding-left for sidebar */}
        
        <div className="mb-20">
          <h2 className="text-6xl md:text-8xl font-serif text-white/10 absolute -top-12 left-0 select-none pointer-events-none z-0">
            BIBLIOGRAPHY
          </h2>
          <h3 className="relative z-10 text-3xl font-header font-bold text-white tracking-widest border-l-4 border-brand-red pl-6">
            LATEST RELEASES
          </h3>
        </div>

        <div className="flex flex-col gap-32">
          {BOOKS.map((book, index) => (
            <div key={book.id} className={`flex flex-col md:flex-row gap-12 items-center ${index % 2 === 1 ? 'md:flex-row-reverse' : ''}`}>
              
              {/* Cover Art */}
              <div className="w-full md:w-1/2 relative group cursor-pointer">
                <div className="absolute -inset-4 border border-white/10 group-hover:border-brand-red/50 transition-colors duration-500"></div>
                <div className="relative aspect-[2/3] overflow-hidden grayscale group-hover:grayscale-0 transition-all duration-700">
                  <img src={book.coverImage} alt={book.title} className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-700" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-80"></div>
                </div>
              </div>

              {/* Details */}
              <div className="w-full md:w-1/2 flex flex-col gap-6">
                <div className="flex items-center gap-4">
                  <span className={`px-3 py-1 text-[10px] font-bold tracking-widest uppercase border ${book.status === 'Available' ? 'border-green-500 text-green-500' : 'border-brand-red text-brand-red'}`}>
                    {book.status}
                  </span>
                  <span className="text-xs text-gray-500 font-header tracking-widest">{book.releaseDate}</span>
                </div>
                
                <div>
                  <h4 className="text-gray-400 font-header tracking-[0.2em] text-sm mb-2">{book.subtitle}</h4>
                  <h2 className="text-4xl md:text-6xl font-header font-bold text-white mb-6 uppercase leading-none">{book.title}</h2>
                  <div className="h-1 w-12 bg-brand-red mb-6"></div>
                  <p className="text-gray-300 font-sans leading-relaxed text-lg max-w-md">
                    {book.description}
                  </p>
                </div>

                <div className="mt-8 flex gap-6">
                  <button className="text-brand-red font-header font-bold tracking-widest text-sm hover:text-white transition-colors border-b border-brand-red pb-1">
                    READ EXCERPT
                  </button>
                  <button className="text-white font-header font-bold tracking-widest text-sm hover:text-brand-red transition-colors border-b border-white hover:border-brand-red pb-1">
                    {book.status === 'Available' ? 'BUY NOW' : 'PRE-ORDER'}
                  </button>
                </div>
              </div>

            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default BookSection;