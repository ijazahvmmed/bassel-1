import React, { useEffect } from 'react';
import Navigation from './components/Navigation';
import Hero from './components/Hero';
import BookSection from './components/BookSection';
import WorldLore from './components/WorldLore';
import Footer from './components/Footer';

const App: React.FC = () => {
  
  // Smooth scroll behavior
  useEffect(() => {
    document.documentElement.style.scrollBehavior = 'smooth';
    return () => {
      document.documentElement.style.scrollBehavior = 'auto';
    };
  }, []);

  return (
    <div className="bg-black min-h-screen text-white selection:bg-brand-red selection:text-white">
      <Navigation />
      
      <main className="flex flex-col">
        <Hero />
        <BookSection />
        
        {/* Quote Interstitial */}
        <section className="py-32 px-6 bg-brand-dark flex justify-center items-center relative overflow-hidden">
           <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-10"></div>
           <blockquote className="relative z-10 max-w-4xl text-center">
              <p className="font-serif text-2xl md:text-4xl text-gray-300 italic leading-relaxed">
                "The gods did not die. They merely forgot how to be kind. Now, in the silence of their apathy, we must forge our own divinity from steel and sorrow."
              </p>
              <footer className="mt-8 text-brand-red font-header font-bold tracking-widest text-sm">
                — EXCERPT FROM THE IRON CROWN
              </footer>
           </blockquote>
        </section>

        <WorldLore />
        
        <section id="author" className="py-24 bg-black relative">
           <div className="container mx-auto px-6 md:px-12 md:pl-32 flex flex-col md:flex-row items-center gap-12">
              <div className="w-full md:w-1/3">
                 <div className="relative aspect-[3/4] border border-white/10 p-2">
                    <img src="https://picsum.photos/600/800?grayscale&random=9" alt="Author Portrait" className="w-full h-full object-cover grayscale contrast-125" />
                 </div>
              </div>
              <div className="w-full md:w-2/3">
                 <h2 className="text-5xl font-header font-bold text-white mb-6 uppercase">About the Author</h2>
                 <div className="h-1 w-24 bg-brand-red mb-8"></div>
                 <p className="text-gray-300 font-sans text-lg leading-relaxed mb-6">
                    Elias Vance is a speculative fiction author known for blending dark fantasy with industrial horror. Based in the Pacific Northwest, his work explores themes of collapsed theocracies, mechanical apotheosis, and the cost of survival in unforgiving worlds.
                 </p>
                 <p className="text-gray-300 font-sans text-lg leading-relaxed">
                    When not writing, he can be found restoring vintage typewriters or exploring abandoned brutalist architecture.
                 </p>
              </div>
           </div>
        </section>

        <Footer />
      </main>
    </div>
  );
};

export default App;