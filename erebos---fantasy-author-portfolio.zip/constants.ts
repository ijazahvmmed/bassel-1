import { Book, LoreItem, NavLink } from './types';

export const AUTHOR_NAME = "ELIAS VANCE";
export const HERO_TITLE = "THE AETHER CYCLE";
export const HERO_SUBTITLE = "WHERE GODS BLEED AND EMPIRES BURN";

export const NAV_LINKS: NavLink[] = [
  { label: 'HOME', href: '#home' },
  { label: 'BOOKS', href: '#books' },
  { label: 'WORLD', href: '#world' },
  { label: 'AUTHOR', href: '#author' },
];

export const BOOKS: Book[] = [
  {
    id: '1',
    title: 'IRON CROWN',
    subtitle: 'BOOK ONE: THE FALL',
    description: 'In a world fueled by the blood of dead deities, a scavenger finds a relic that whispers the true name of the Emperor. Hunted by the Red Inquisitors, he must cross the Ash Wastes to deliver a truth that will shatter the sky.',
    coverImage: 'https://picsum.photos/600/900?grayscale&random=1',
    releaseDate: 'AVAILABLE NOW',
    status: 'Available'
  },
  {
    id: '2',
    title: 'ASHEN THRONE',
    subtitle: 'BOOK TWO: THE RISE',
    description: 'The Emperor is dead, but the void left behind is hungrier than any tyrant. As factions vie for control of the Aether Wells, an ancient enemy stirs beneath the capital, ready to consume the victors.',
    coverImage: 'https://picsum.photos/600/900?grayscale&random=2',
    releaseDate: 'COMING WINTER 2024',
    status: 'Pre-Order'
  }
];

export const LORE_ITEMS: LoreItem[] = [
  {
    id: 'l1',
    title: 'THE RED PRIESTS',
    excerpt: 'Fanatics who consume aether to prolong their lives, turning their veins into glowing webs of power.',
    image: 'https://picsum.photos/800/600?grayscale&random=3',
    category: 'Culture'
  },
  {
    id: 'l2',
    title: 'THE ASH WASTES',
    excerpt: 'A continent-spanning desert of grey dust where the sun never fully pierces the smog clouds.',
    image: 'https://picsum.photos/800/600?grayscale&random=4',
    category: 'Location'
  },
  {
    id: 'l3',
    title: 'SUN-EATER',
    excerpt: 'A weapon from the First Era, capable of drinking the light from a star to power the engines of war.',
    image: 'https://picsum.photos/800/600?grayscale&random=5',
    category: 'Artifact'
  }
];